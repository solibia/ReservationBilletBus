package com.ensat.controllers;

import org.springframework.stereotype.Controller;


/**
 * Client controller.
 */
@Controller
public class ClientController {

}
