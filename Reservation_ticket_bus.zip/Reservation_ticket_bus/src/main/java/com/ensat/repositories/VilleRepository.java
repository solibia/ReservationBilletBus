package com.ensat.repositories;

import com.ensat.entities.Ville;

import org.springframework.data.repository.CrudRepository;


public interface VilleRepository extends CrudRepository<Ville, Integer> {
	
}
